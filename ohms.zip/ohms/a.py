class Customers:
    def __init__(self,cutomers_id,customers_type):
    self.__customers_id=__customers_id
    self.__customer_type=__customer_type
    self.__