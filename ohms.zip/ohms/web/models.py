from django.db import models

# Create your models here.
class patient(models.Model):

    username = models.CharField(max_length=1000)
    father_name = models.CharField(max_length=1000)
    age = models.CharField(max_length=4)
    address = models.TextField()
    pin_code = models.CharField(max_length=10)
    email = models.TextField()
    img = models.ImageField(upload_to='pics')
    mobile_no = models.CharField(max_length=10)
    password = models.CharField(max_length=100)

class doctor(models.Model):

    username = models.CharField(max_length=1000)
    mob = models.CharField(max_length=10)
    qualification = models.CharField(max_length=1000)
    add = models.TextField()
    pin_code = models.TextField(max_length=10)
    age = models.CharField(max_length=4)
    specialization = models.CharField(max_length=100)
    email = models.TextField()
    img1 = models.ImageField(upload_to='pics1')
    img2 = models.ImageField(upload_to='pics2')
    password = models.CharField(max_length=100)



