from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('logindoctor/', views.logindoctor, name='logindoctor'),
    path('loginpatient/', views.loginpatient, name='loginpatient'),
    path('signuppatient/', views.signuppatient, name='signuppatient'),
    path('signupdoctor/', views.signupdoctor, name='signupdoctor'),

]