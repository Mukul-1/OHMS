from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
from web.models import doctor, patient
# Create your views here.
def index(request):
    return render(request, 'index.html')

def logindoctor(request):
    return render(request, 'logindoctor.html')

def loginpatient(request):
    return render(request, 'loginpatient.html')

def signuppatient(request):

    if request.method == 'POST':
        username = request.POST['username']
        fname = request.POST['fname']
        age = request.POST['age']
        add = request.POST['add']
        pin_code = request.POST['pin_code']
        email = request.POST['email']
        img = request.POST['your_img']
        mob = request.POST['mob']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        pat =patient(
            username=username,
            father_name=fname,
            age=age,
            address=add,
            pin_code=pin_code,
            email=email,
            img=img,
            mobile_no=mob,
            password=password1
        )
        pat.save()

        return render(request, 'loginpatient.HTML', {"message": "Patient created.Login here......"})

    else:
        return render(request, 'signuppatient.html')

def signupdoctor(request):

    if request.method == 'POST':
        username = request.POST['username']
        mob = request.POST['mob_no']
        qualification = request.POST['qualification']
        add = request.POST['add']
        pin_code = request.POST['pin_code']
        age = request.POST['age']
        specialization = request.POST['specialization']
        email = request.POST['email']
        img1 = request.POST['img_certificate']
        img2 = request.POST['your_img']
        password1 = request.POST['password']
        password2 = request.POST['password_confirm']

        doc = doctor(
            username=username,
            mob=mob,
            qualification=qualification,
            add=add,
            pin_code=pin_code,
            age=age,
            specialization=specialization,
            email=email,
            img1=img1,
            img2=img2,
            password=password1
        )
        doc.save()
        return HttpResponse("doctor created")

    else:
        return render(request, 'signupdoctor.html')

